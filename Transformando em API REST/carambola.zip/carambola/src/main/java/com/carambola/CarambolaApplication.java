package com.carambola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarambolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarambolaApplication.class, args);
	}

}
