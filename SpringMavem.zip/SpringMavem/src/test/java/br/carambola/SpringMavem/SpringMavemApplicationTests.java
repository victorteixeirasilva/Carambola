package br.carambola.SpringMavem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMavemApplicationTests {

	@Test
	void contextLoads() {
	}

}
