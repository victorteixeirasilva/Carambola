package br.carambola.SpringMaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
